# Data Directory Files

This document has been relocated to https://zcash.readthedocs.io/en/latest/rtd_pages/files.html

The source for this document is available at https://gitlab.com/zcash-docs/zcash-docs/blob/master/source/rtd_pages/files.rst
