Compiling/running automated tests
---------------------------------

This document has been relocated to https://zcash.readthedocs.io/en/latest/rtd_pages/development_guidelines.html#testing

The source for this document is available at https://gitlab.com/zcash-docs/zcash-docs/blob/master/source/rtd_pages/development_guidelines.rst
